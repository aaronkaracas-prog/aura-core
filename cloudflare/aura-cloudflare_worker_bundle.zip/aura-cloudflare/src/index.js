/**
 * aura-cloudflare — delegated Cloudflare Control Plane for Aura
 *
 * Hard rules:
 * - No deletes (no DNS delete, no route delete)
 * - Allowed zones only (env.ALLOWED_ZONES CSV)
 * - Auth required (HMAC)
 * - Explicit, auditable responses (no silent success)
 *
 * Auth scheme (HMAC-SHA256):
 * Headers:
 *   X-Aura-TS: unix epoch seconds (string)
 *   X-Aura-Sig: hex(hmac_sha256(AURA_CORE_SECRET, `${ts}\n${body}`))
 * Notes:
 * - body is the raw request body string (empty string for GET)
 * - request must arrive within 60 seconds of X-Aura-TS
 */

const API_BASE = "https://api.cloudflare.com/client/v4";

function json(obj, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...extraHeaders,
    },
  });
}

function badRequest(msg, extra = {}) {
  return json({ ok: false, error: "bad_request", detail: msg, ...extra }, 400);
}
function unauthorized(detail = "unauthorized") {
  return json({ ok: false, error: "unauthorized", detail }, 401);
}
function forbidden(detail = "forbidden") {
  return json({ ok: false, error: "forbidden", detail }, 403);
}
function notFound(detail = "not_found") {
  return json({ ok: false, error: "not_found", detail }, 404);
}
function methodNotAllowed() {
  return json({ ok: false, error: "method_not_allowed" }, 405);
}

function normalizeZoneName(z) {
  return String(z || "").trim().toLowerCase();
}
function parseAllowedZones(env) {
  const raw = (env.ALLOWED_ZONES || "").trim();
  if (!raw) return [];
  return raw
    .split(",")
    .map((s) => normalizeZoneName(s))
    .filter(Boolean);
}
function isZoneAllowed(env, zoneName) {
  const allowed = parseAllowedZones(env);
  if (allowed.length === 0) return false; // explicit allow-list required
  return allowed.includes(normalizeZoneName(zoneName));
}

async function hmacSha256Hex(secret, data) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  const bytes = new Uint8Array(sig);
  let hex = "";
  for (const b of bytes) hex += b.toString(16).padStart(2, "0");
  return hex;
}

async function verifyAuth(request, env, rawBody) {
  const secret = env.AURA_CORE_SECRET;
  if (!secret) return { ok: false, reason: "missing_AURA_CORE_SECRET" };

  const ts = request.headers.get("X-Aura-TS");
  const sig = request.headers.get("X-Aura-Sig");
  if (!ts || !sig) return { ok: false, reason: "missing_auth_headers" };

  const tsNum = Number(ts);
  if (!Number.isFinite(tsNum) || tsNum <= 0) return { ok: false, reason: "bad_timestamp" };

  const now = Math.floor(Date.now() / 1000);
  const skew = Math.abs(now - tsNum);
  if (skew > 60) return { ok: false, reason: "timestamp_out_of_window", skew_seconds: skew };

  const data = `${ts}\n${rawBody || ""}`;
  const expected = await hmacSha256Hex(secret, data);

  // constant-time-ish compare
  if (expected.length !== sig.length) return { ok: false, reason: "bad_signature" };
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i);
  if (diff !== 0) return { ok: false, reason: "bad_signature" };

  return { ok: true };
}

async function cfFetch(env, path, init = {}) {
  const token = env.CF_API_TOKEN;
  if (!token) throw new Error("missing_CF_API_TOKEN");
  const url = `${API_BASE}${path}`;
  const headers = new Headers(init.headers || {});
  headers.set("Authorization", `Bearer ${token}`);
  headers.set("Content-Type", "application/json");
  const resp = await fetch(url, { ...init, headers });
  const data = await resp.json().catch(() => null);
  if (!resp.ok || !data || data.success === false) {
    return { ok: false, status: resp.status, data };
  }
  return { ok: true, status: resp.status, data };
}

// Cache zones by name in-memory (best-effort)
const ZONE_CACHE = new Map(); // name -> { id, name }

async function resolveZoneId(env, zoneName) {
  const zn = normalizeZoneName(zoneName);
  if (!zn) return { ok: false, error: "missing_zone" };
  if (!isZoneAllowed(env, zn)) return { ok: false, error: "zone_not_allowed", zone: zn };

  const cached = ZONE_CACHE.get(zn);
  if (cached?.id) return { ok: true, zone_id: cached.id, zone_name: cached.name || zn };

  // Cloudflare zones API supports name filter
  const r = await cfFetch(env, `/zones?name=${encodeURIComponent(zn)}&status=active&page=1&per_page=1`, { method: "GET" });
  if (!r.ok) return { ok: false, error: "cf_error", detail: r.data };
  const result = r.data?.result || [];
  if (!result.length) return { ok: false, error: "zone_not_found", zone: zn };

  const zone = result[0];
  ZONE_CACHE.set(zn, { id: zone.id, name: zone.name });
  return { ok: true, zone_id: zone.id, zone_name: zone.name };
}

function assertNoWildcards(name) {
  const n = String(name || "").trim();
  if (!n) return { ok: false, detail: "missing_name" };
  if (n.includes("*")) return { ok: false, detail: "wildcards_not_allowed" };
  return { ok: true, name: n };
}

function assertRecordType(type) {
  const t = String(type || "").trim().toUpperCase();
  const allowed = new Set(["A", "AAAA", "CNAME", "TXT", "MX", "SRV", "CAA"]);
  if (!allowed.has(t)) return { ok: false, detail: "unsupported_type" };
  return { ok: true, type: t };
}

function assertRoutePattern(pattern) {
  const p = String(pattern || "").trim();
  if (!p) return { ok: false, detail: "missing_pattern" };
  if (!p.includes("/*")) return { ok: false, detail: "pattern_must_end_with_slash_star" };
  if (p.includes("*") && !p.endsWith("/*")) return { ok: false, detail: "only_trailing_wildcard_allowed" };
  return { ok: true, pattern: p };
}

async function zoneInspect(env, body) {
  const z = body?.zone;
  const rz = await resolveZoneId(env, z);
  if (!rz.ok) return json({ ok: false, error: rz.error, ...rz }, rz.error === "zone_not_allowed" ? 403 : 404);

  const zone_id = rz.zone_id;

  const dns = await cfFetch(env, `/zones/${zone_id}/dns_records?per_page=50`, { method: "GET" });
  if (!dns.ok) return json({ ok: false, error: "cf_error", action: "list_dns", detail: dns.data }, 502);

  const routes = await cfFetch(env, `/zones/${zone_id}/workers/routes?per_page=50`, { method: "GET" });
  if (!routes.ok) return json({ ok: false, error: "cf_error", action: "list_routes", detail: routes.data }, 502);

  return json({
    ok: true,
    zone: rz.zone_name,
    zone_id,
    dns_count: dns.data?.result?.length || 0,
    routes_count: routes.data?.result?.length || 0,
    sample: {
      dns: (dns.data?.result || []).slice(0, 5).map((r) => ({
        id: r.id,
        type: r.type,
        name: r.name,
        content: r.content,
        proxied: r.proxied,
        ttl: r.ttl,
      })),
      routes: (routes.data?.result || []).slice(0, 5).map((r) => ({
        id: r.id,
        pattern: r.pattern,
        script: r.script,
      })),
    },
  });
}

async function dnsUpsert(env, body) {
  const { zone, type, name, content, proxied, ttl, priority, data } = body || {};
  const rz = await resolveZoneId(env, zone);
  if (!rz.ok) return json({ ok: false, error: rz.error, ...rz }, rz.error === "zone_not_allowed" ? 403 : 404);

  const t = assertRecordType(type);
  if (!t.ok) return badRequest(t.detail);

  const nn = assertNoWildcards(name);
  if (!nn.ok) return badRequest(nn.detail);

  const recName = nn.name.includes(".") ? nn.name : `${nn.name}.${rz.zone_name}`; // allow relative names
  if (!content && !data) return badRequest("missing_content_or_data");

  const zone_id = rz.zone_id;

  // find existing record by type+name
  const q = await cfFetch(
    env,
    `/zones/${zone_id}/dns_records?type=${encodeURIComponent(t.type)}&name=${encodeURIComponent(recName)}&page=1&per_page=1`,
    { method: "GET" }
  );
  if (!q.ok) return json({ ok: false, error: "cf_error", action: "query_dns", detail: q.data }, 502);

  const existing = (q.data?.result || [])[0];
  const payload = {
    type: t.type,
    name: recName,
    content: content,
    ttl: typeof ttl === "number" ? ttl : 1,
    proxied: typeof proxied === "boolean" ? proxied : undefined,
    priority: typeof priority === "number" ? priority : undefined,
    data: data && typeof data === "object" ? data : undefined,
  };

  // remove undefined fields
  Object.keys(payload).forEach((k) => payload[k] === undefined && delete payload[k]);

  if (existing?.id) {
    const u = await cfFetch(env, `/zones/${zone_id}/dns_records/${existing.id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
    if (!u.ok) return json({ ok: false, error: "cf_error", action: "update_dns", detail: u.data }, 502);

    return json({
      ok: true,
      action: "updated",
      zone: rz.zone_name,
      record: { id: existing.id, type: t.type, name: recName, content: payload.content, proxied: payload.proxied, ttl: payload.ttl },
    });
  } else {
    const c = await cfFetch(env, `/zones/${zone_id}/dns_records`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    if (!c.ok) return json({ ok: false, error: "cf_error", action: "create_dns", detail: c.data }, 502);

    const created = c.data?.result;
    return json({
      ok: true,
      action: "created",
      zone: rz.zone_name,
      record: { id: created?.id, type: t.type, name: recName, content: created?.content, proxied: created?.proxied, ttl: created?.ttl },
    });
  }
}

async function workersRouteUpsert(env, body) {
  const { zone, pattern, script } = body || {};
  const rz = await resolveZoneId(env, zone);
  if (!rz.ok) return json({ ok: false, error: rz.error, ...rz }, rz.error === "zone_not_allowed" ? 403 : 404);

  const pp = assertRoutePattern(pattern);
  if (!pp.ok) return badRequest(pp.detail);

  const sc = String(script || "").trim();
  if (!sc) return badRequest("missing_script");

  const zone_id = rz.zone_id;

  // list routes to find existing pattern
  const l = await cfFetch(env, `/zones/${zone_id}/workers/routes?per_page=100`, { method: "GET" });
  if (!l.ok) return json({ ok: false, error: "cf_error", action: "list_routes", detail: l.data }, 502);

  const routes = l.data?.result || [];
  const existing = routes.find((r) => r.pattern === pp.pattern);

  const payload = { pattern: pp.pattern, script: sc };

  if (existing?.id) {
    const u = await cfFetch(env, `/zones/${zone_id}/workers/routes/${existing.id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
    if (!u.ok) return json({ ok: false, error: "cf_error", action: "update_route", detail: u.data }, 502);

    return json({
      ok: true,
      action: "updated",
      zone: rz.zone_name,
      route: { id: existing.id, pattern: pp.pattern, script: sc },
    });
  } else {
    const c = await cfFetch(env, `/zones/${zone_id}/workers/routes`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    if (!c.ok) return json({ ok: false, error: "cf_error", action: "create_route", detail: c.data }, 502);

    const created = c.data?.result;
    return json({
      ok: true,
      action: "created",
      zone: rz.zone_name,
      route: { id: created?.id, pattern: pp.pattern, script: sc },
    });
  }
}

async function readJson(request) {
  const text = await request.text();
  if (!text) return { raw: "", json: null };
  try {
    return { raw: text, json: JSON.parse(text) };
  } catch {
    return { raw: text, json: null, parse_error: true };
  }
}

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);
      const { pathname } = url;

      // health is unauthenticated (read-only, no secrets)
      if (pathname === "/health") {
        return json({
          ok: true,
          service: "aura-cloudflare",
          allowed_zones: parseAllowedZones(env),
          has_token: !!env.CF_API_TOKEN,
          has_secret: !!env.AURA_CORE_SECRET,
          ts: Math.floor(Date.now() / 1000),
        });
      }

      // All other endpoints require auth
      const { raw, json: body, parse_error } = await readJson(request);
      const auth = await verifyAuth(request, env, raw || "");
      if (!auth.ok) return unauthorized(auth.reason);

      if (request.method !== "POST") return methodNotAllowed();
      if (parse_error) return badRequest("bad_json");

      if (pathname === "/zone/inspect") {
        return await zoneInspect(env, body);
      }
      if (pathname === "/dns/upsert") {
        return await dnsUpsert(env, body);
      }
      if (pathname === "/workers/route") {
        return await workersRouteUpsert(env, body);
      }

      return notFound("unknown_endpoint");
    } catch (err) {
      return json({ ok: false, error: "unhandled_exception", detail: String(err?.message || err) }, 500);
    }
  },
};
